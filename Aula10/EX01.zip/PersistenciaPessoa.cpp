#include "PersistenciaPessoa.h"
#include <fstream>

PersistenciaPessoa::PersistenciaPessoa(string arquivo) {
    this->arquivo = arquivo;
}

PersistenciaPessoa::~PersistenciaPessoa() {}

void PersistenciaPessoa::inserir(Pessoa *p) {
    ofstream output;
    output.open (this->arquivo, ios_base::app);

    if (output.fail()) {
        cout << "Arquivo nao encontrado" << endl;
        output.close();
    }

    output << p->getNome() << "\n";
    output << p->getValorPorHora() << "\n";
    output << p->getHorasDiarias() << "\n";

    output.close();
}
