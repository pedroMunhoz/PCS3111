#include "PersistenciaPessoa.h"
#include <fstream>
#include <stdexcept>

PersistenciaPessoa::PersistenciaPessoa(string arquivo) {
    this->arquivo = arquivo;
}

PersistenciaPessoa::~PersistenciaPessoa() {}

void PersistenciaPessoa::inserir(Pessoa *p) {
    ofstream output;
    output.open (this->arquivo, ios_base::app);

    if (output.fail()) {
        cout << "Arquivo nao encontrado" << endl;
        output.close();
    }

    output << p->getNome() << "\n";
    output << p->getValorPorHora() << "\n";
    output << p->getHorasDiarias() << "\n";

    output.close();
}

Pessoa** PersistenciaPessoa::obter(int& quantidade){
    quantidade = 0;
    int i = 0;

    Pessoa** pessoas;

    ifstream input;
    input.open(this->arquivo);

    if (input.fail()) {
        throw new invalid_argument ("Argumento inválido");
        input.close();
        return NULL;
    }

    string linhaS;
    int linhaI;
    input >> linhaS;

    while(input) {
        quantidade++;
        pessoas = new Pessoa*[quantidade];

        string nome = linhaS;
        input >> linhaI;
        int valorPorHora = linhaI;
        input >> linhaI;
        int horasDiarias = linhaI;

        pessoas[i] = new Pessoa(nome, valorPorHora, horasDiarias);
        i++;

        input >> linhaS;
    }

    if (!input.eof()) throw new logic_error ("Erro lógico");

    if (quantidade == 0) return NULL;

    return pessoas;
}
