#ifndef PESSOA_H
#define PESSOA_H

#include "Recurso.h"

// Faca os includes necessarios
#include<string>
using namespace std;

class Pessoa :public Recurso {
public:
    Pessoa(string nome, double valorPorHora, int horasDiarias);
    virtual ~Pessoa();

    virtual double getValorPorHora();
    virtual int getHorasDiarias();

    double getCusto(int dias);
private:
    double valorPorHora;
    int horasDiarias;
};

#endif // PESSOA_H
