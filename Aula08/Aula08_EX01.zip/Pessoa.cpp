#include "Pessoa.h"

Pessoa::Pessoa(string nome, double valorPorHora, int horasDiarias) : Recurso(nome) {
    this->nome = nome;
    this->valorPorHora = valorPorHora;
    this->horasDiarias = horasDiarias;
}

Pessoa::~Pessoa() {}

double Pessoa::getValorPorHora() {
    return this->valorPorHora;
}

int Pessoa::getHorasDiarias() {
    return this->horasDiarias;
}

double Pessoa::getCusto(int dias) {
    return dias*this->horasDiarias*this->valorPorHora;
}