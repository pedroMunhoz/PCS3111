#ifndef PROJETO_H
#define PROJETO_H

#include <string>
#include "Atividade.h"
#include "Pessoa.h"
#include <vector>

using namespace std;

class Projeto {
public:
    Projeto(string nome, int maximoValor);
    ~Projeto();

    int getDuracao();
    int getQuantidadePessoas();
    vector<Atividade*>* getAtividades();
    Pessoa** getPessoas();

    void adicionar(Atividade* a);
    void adicionar(Pessoa* p);
private:
    string nome;
    int maximoValor;
    int quantidadePessoas;
    vector<Atividade*>* atividades = new vector<Atividade*>();
    Pessoa** pessoas;
};

#endif // PROJETO_H
