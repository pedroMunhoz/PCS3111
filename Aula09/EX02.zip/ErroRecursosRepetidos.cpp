#include "ErroRecursosRepetidos.h"

ErroRecursosRepetidos::ErroRecursosRepetidos(string msg) : invalid_argument(msg) {}
ErroRecursosRepetidos::~ErroRecursosRepetidos() {}